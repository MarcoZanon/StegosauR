#' decosaur function
#'
#' This function takes an image produced via function \code{\link{encosaur}} and extracts its hidden text.
#'
#'
#' @author Marco Zanon , \email{marco[at]zanon.xyz}
#'
#' @param input Any tiff/tif image produced via function \code{\link{encosaur}}.
#' @param secret Numeric or character vector. Must match the \code{secret} used to encrypt the original message. Default = "StegosauR password".
#' @param salt Optional. Numeric or character vector. Must match the \code{salt}, if any, used to encrypt the original message.
#'
#' @return Returns a decoded text message.
#'
#' @import magrittr
#' @import tiff
#' @import openssl
#' @import Unicode
#' @import dplyr
#' @importFrom stats setNames
#'
#' @examples
#'
#' #load sample image
#'
#' img <- system.file("img", "encoded_Marsh_1891_Stegosaurus.tiff", package="StegosauR")
#'
#' #decode message
#'
#' decosaur(input=img, secret="123", salt="456")
#'
#' @export


decosaur <- function(input, secret= "StegosauR password", salt=NA) {

#temporarily change options to suppress exponential notation
opt <- options(scipen = 100, digits=10)
on.exit(options(opt))

img <- readTIFF(input, convert=FALSE)

#get y and x dimensions
dims <- c(dim(img))

#hash the secret passphrase
scrt_sha <- sha512(as.character(secret), key = as.character(salt))

#change to decimal
#based on: https://stackoverflow.com/questions/27442991/how-to-get-a-hash-code-as-integer-in-r
hex_to_int = function(h) {
  xx = strsplit(tolower(h), "")[[1L]]
  pos = match(xx, c(0L:9L, letters[1L:6L]))
}

int_sha <- paste(hex_to_int(scrt_sha), collapse="")

#get first, middle, and last 3 characters of int_sha. These will be used for the pseudo-random number generation
int_sha.head <- as.numeric(substr(int_sha,1,3))
int_sha.mid <- as.numeric(substr(int_sha,floor((nchar(int_sha)/2))-0,floor((nchar(int_sha)/2))+2))
int_sha.tail <- as.numeric(substr(int_sha,nchar(int_sha)-2,nchar(int_sha)))


#get the first 12 coordinates in order to know the message length

len <- 12*3*3 #12 digits and 3 columns (x,y,channel)
#The final multiplication by 3 comes into play later, so part of the random number can be discarded after rescaling.

pseud_rand <- numeric(len)

pseud_rand[1] <- as.numeric(paste(int_sha.head, int_sha.mid, int_sha.tail, sep = ""))

for (i in 2:len) {


  a <-  as.numeric(substr(magrittr::mod((int_sha.head*log(i)*pseud_rand[i-1])+int_sha.mid*log(i), int_sha.tail*2^32),1,3))
  b <-  as.numeric(substr(magrittr::mod((int_sha.tail*log(i)*pseud_rand[i-1])+int_sha.head*log(i), int_sha.mid*2^32),1,3))
  c <-  as.numeric(substr(magrittr::mod((int_sha.mid*log(i)*pseud_rand[i-1])+int_sha.tail*log(i), int_sha.head*2^32),1,3))

  pseud_rand[i] <- as.numeric(paste(a,b,c,sep=""))

                                    #this whole mess of pasting is needed because different version of R on different Operating Systems might give different results
                                    #when calculating the modulo. The first 4-5 digits are usually the same from my tests. But I still need a long number to avoid
                                    #producing too many duplicates when rescaling.

  #pseud_rand[i] <- mod(((35*log(i))*pseud_rand[i-1])+528+log(i), 2547-log(i))
}

#select only number in odd or even positions and move them around to break a bit the pattern of simlar numbers.
#code from: https://stackoverflow.com/questions/13461829/select-every-other-element-from-a-vector
pseud_rand.shift <- c(pseud_rand[c(TRUE,FALSE)], rev(pseud_rand[c(FALSE,TRUE)]))

#subtract the rearranged numbers from the pseudo_rand vector. This helps to counter the fact that all numbers have the same lenght, adding some diversity.
pseud_rand.subt <- abs(pseud_rand-rev(pseud_rand.shift))

#fill matrix

#rescale the content of each column:
# - column x contains integers between 1 and dims[2]
# - column y contains integers between 1 and dims[1]
# - column channel contains integers between 1 and dims[3]

length_mx <- as.data.frame(matrix(pseud_rand.subt, nrow = 12*3, ncol = 3, byrow=TRUE))
colnames(length_mx) <- c("x","y","channel")


#rescale x
min_x_new <- 1
max_x_new <- dims[2]

min_x_old <- min(length_mx[,1])
max_x_old <- max(length_mx[,1])

length_mx[,1] <- floor(((max_x_new-min_x_new)/(max_x_old-min_x_old))*(length_mx[,1]-max_x_old)+max_x_new)

#rescale y
min_y_new <- 1
max_y_new <- dims[1]

min_y_old <- min(length_mx[,2])
max_y_old <- max(length_mx[,2])

length_mx[,2] <- floor(((max_y_new-min_y_new)/(max_y_old-min_y_old))*(length_mx[,2]-max_y_old)+max_y_new)

#rescale channel
min_c_new <- 1
max_c_new <-dims[3]

min_c_old <- min(length_mx[,3])
max_c_old <- max(length_mx[,3])

length_mx[,3] <- floor(((max_c_new-min_c_new)/(max_c_old-min_c_old))*(length_mx[,3]-max_c_old)+max_c_new)

#nrow(length_mx)

#change any 0 into 1. The floor function above might generate 0 if the output of the rescaling is a 1
length_mx[length_mx == 0 ] <- 1

#remove duplicate rows (same combination of x, y and channel)
length_mx <- unique(length_mx)
#nrow(length_mx)

#keep only 12 rows
length_mx <- length_mx[13:24,]
#nrow(length_mx)


#extract value from pixel

extract_value <- function(x) {

  yval <- x[2]
  xval <- x[1]
  cval <- x[3]

  code <-img[yval,xval,cval]

  return(code)

}


length_mx$code <- apply(length_mx, 1, extract_value)


length_mx$code_1 <- as.numeric(substr(length_mx$code,5,6))+1

length_mx$code_2 <- as.numeric(substr(length_mx$code_1,nchar(length_mx$code_1)-1,nchar(length_mx$code_1)-1))

length_mx$code_2[is.na(length_mx$code_2)] <- 0 #replace Nas with 0s


message_length <- as.numeric(paste(length_mx$code_2, collapse=""))


#produce the remaining coordinates

len <- (((message_length*3)*12)*3) #this is the total number of pseudo-random number to generate. length of text * 3 columns * 12 integers and replicated again three times
#the final multiplication by 3 comes into play later, so part of the random number can be discarded after rescaling.
#the +(12*3) is added to store information on text length in a 12-digit format. The value is multiplied by 3 to produce extra coordinates, as above.

start_rand <- pseud_rand[i] #store the last pseudo random value and use it to continue with number generation.

pseud_rand <- numeric(len)

pseud_rand[1] <- start_rand

for (h in 2:len) {

  a <-  as.numeric(substr(magrittr::mod((int_sha.head*log(h)*pseud_rand[h-1])+int_sha.mid*log(h), int_sha.tail*2^32),1,3))
  b <-  as.numeric(substr(magrittr::mod((int_sha.tail*log(h)*pseud_rand[h-1])+int_sha.head*log(h), int_sha.mid*2^32),1,3))
  c <-  as.numeric(substr(magrittr::mod((int_sha.mid*log(h)*pseud_rand[h-1])+int_sha.tail*log(h), int_sha.head*2^32),1,3))

  pseud_rand[h] <- as.numeric(paste(a,b,c,sep=""))

  #pseud_rand[h] <- mod(((35*log(h))*pseud_rand[h-1])+528+log(h), 2547-log(h))
}

#select only number in odd or even positions and move them around to break a bit the pattern of simlar numbers.
#code from: https://stackoverflow.com/questions/13461829/select-every-other-element-from-a-vector
pseud_rand.shift <- c(pseud_rand[c(TRUE,FALSE)], rev(pseud_rand[c(FALSE,TRUE)]))

#subtract the rearranged numbers from the pseudo_rand vector. This helps to counter the fact that all numbers have the same lenght, adding some diversity.
pseud_rand.subt <- abs(pseud_rand-rev(pseud_rand.shift))


#fill matrix
mx <- as.data.frame(matrix(pseud_rand.subt, nrow = message_length*3*12, ncol = 3, byrow=TRUE))
colnames(mx) <- c("x","y","channel")



#rescale x
min_x_new <- 1
max_x_new <- dims[2]

min_x_old <- min(mx[,1])
max_x_old <- max(mx[,1])

mx[,1] <- floor(((max_x_new-min_x_new)/(max_x_old-min_x_old))*(mx[,1]-max_x_old)+max_x_new)

#rescale y
min_y_new <- 1
max_y_new <- dims[1]

min_y_old <- min(mx[,2])
max_y_old <- max(mx[,2])

mx[,2] <- floor(((max_y_new-min_y_new)/(max_y_old-min_y_old))*(mx[,2]-max_y_old)+max_y_new)

#rescale channel
min_c_new <- 1
max_c_new <-dims[3]

min_c_old <- min(mx[,3])
max_c_old <- max(mx[,3])

mx[,3] <- floor(((max_c_new-min_c_new)/(max_c_old-min_c_old))*(mx[,3]-max_c_old)+max_c_new)

#nrow(mx)

#remove duplicate rows (same combination of x, y and channel)
mx <- unique(mx)
#nrow(mx)

#restore the original structure of length_mx
length_mx <- length_mx[,1:3]

#add the two data frames
all_mx <- rbind(length_mx, mx)

#change any 0 into 1. The floor function above might generate 0 if the output of the rescaling is a 1
all_mx[all_mx == 0 ] <- 1

#remove unique
all_mx <- unique(all_mx)
#nrow(all_mx)

#remove all the rows contained in length_mx
mx <- dplyr::setdiff(all_mx, length_mx)
#nrow(mx)


#add what remains to length_mx. In this way it is certain that what remains of mx does not contain duplicates of length_mx
mx <- rbind(length_mx, mx)
#nrow(mx)

#keep only the first message_length rows.
mx <- mx[1:((message_length*12)+12),]
#nrow(mx)

code_seq <- numeric()

for (k in c(13:((message_length*12)+12))) {

  yval <- mx[k,2]
  xval <- mx[k,1]
  cval <- mx[k,3]

  code <-img[yval,xval,cval]

  #debugging
  #if (k > c(13:((message_length*12)))) {
  # print(paste(k, "code ", code, " - x ", xval, ", y ", yval, ", c ",cval))
  #}


  code <- as.numeric(substr(code,5,6))+1

  code <- as.numeric(substr(code,nchar(code)-1,nchar(code)-1))

  code[is.na(code)] <- 0 #replace Nas with 0s

  code_seq <- c(code_seq, code)

}

code_df <- as.data.frame(matrix(code_seq, nrow = message_length, ncol = 12, byrow=TRUE))

#no longer needed
#some column should not be == 0. If they are, then image encoding probably changed some decimal value.
#from testing, it appears that any 0 in these columns might have taken the place of a 1.
#code_df$V1[code_df$V1 == 0] <- 1
#code_df$V3[code_df$V3 == 0] <- 1
#code_df$V5[code_df$V5 == 0] <- 1
#code_df$V7[code_df$V7 == 0] <- 1
#code_df$V9[code_df$V9 == 0] <- 1
#code_df$V11[code_df$V11 == 0] <- 1


code_df$first <- paste(code_df$V1,code_df$V2, sep="")

code_df$second <- paste(code_df$V3,code_df$V4, sep="")

code_df$third <- paste(code_df$V5,code_df$V6, sep="")

code_df$fourth <- paste(code_df$V7,code_df$V8, sep="")

code_df$fifth <- paste(code_df$V9,code_df$V10, sep="")

code_df$sixth <- paste(code_df$V11,code_df$V12, sep="")


#replace each pair of digits with the hexadecimal counterpart
#code take from: https://stackoverflow.com/questions/7547597/dictionary-style-replace-multiple-items

map <- setNames(c("0", "1", "2","3","4","5","6","7","8","9","A","B","C","D","E","F","0","0"),
                c("22", "23","24","25","32","33","34","35","42","43","44","45","52","53","54","55","65","75"))

code_df <- code_df[,13:18]

code_df[] <- map[unlist(code_df)]

code_df$Unicode <- as.u_char(paste(code_df$first,code_df$second,code_df$third,code_df$fourth,code_df$fifth,code_df$sixth, sep=""))

decoded <- paste(sapply(code_df$Unicode, intToUtf8), collapse="")

return(decoded)


}
