#' encosaur function
#'
#' This function takes a user-defined message and hides it into a user-defined image.
#'
#' The core methodology of this package can be summarized in few steps. First, the user-defined message is converted into a numeric string. Then, every individual digit of this numeric string is stored in a unique location within the image. Each location is defined by three coordinates: x, y, and color channel (three possible channels for RGB images). The numeric color value at a give location is slightly altered by pacing the code-bearing digit in a known decimal position.
#' The sequence of locations is defined via a pseudo-random number generator. The seed for number generation is based on the user-defined secret (together with, if specified, the user-defined salt). The encoded text can then be extracted via function \code{\link{decosaur}}.
#'
#' @author Marco Zanon , \email{marco[at]zanon.xyz}
#'
#' @param input Any jpeg/jpg, png or tiff/tif RGB image.
#' @param output Name of the output file. Regardless of the input format, the output file is always a tiff image. The new image is generated in the working directory (use getwd() to see your current path). Be aware that generating a new tiff image might overwrite the original file.
#' @param message Numeric or character vector to hide within the input image.
#' @param secret Numeric or character vector. Password used to encrypt the message. Default = "StegosauR password".
#' @param salt Optional. Numeric or character vector. If this parameter is specified, the encrypted message can be decoded only by knowing both secret and salt.
#' @param noise Logical. If \code{TRUE}, it adds some random noise to all pixels. It might help to hide which locations contain a hidden message, but the added noise could alter visibly the colors of the output image. Default is \code{FALSE}.
#'
#' @return Returns a tiff image hiding an encrypted message.
#'
#' @import magrittr
#' @import jpeg
#' @import png
#' @import tiff
#' @import openssl
#' @import Unicode
#' @import dplyr
#' @importFrom stats setNames
#'
#' @examples
#'
#' #load sample image
#'
#' img <- system.file("img", "Marsh_1891_Stegosaurus.jpg", package="StegosauR")
#'
#' #encode message
#'
#' encosaur(input=img, output="encoded_Marsh_1891_Stegosaurus",
#'          message="Message stored with R package StegosauR v.0.1.0", secret="123", salt="456")
#'
#'
#' @export



encosaur <- function(input, output="output_image", message = "Encrypted with StegosauR", secret= "StegosauR password", salt=NA, noise=FALSE) {

#temporarily change options to suppress exponential notation
opt <- options(scipen = 100, digits=10)
on.exit(options(opt))

ext <- tools::file_ext(input)

if (ext == "jpg" | ext == "jpeg")         {
                                             img <- readJPEG(input)
} else if (ext == "png")                  {
                                             img <- readPNG(input)
} else if (ext == "tiff" | ext == "tif")  {
                                             img <- readTIFF(input)
} else                                    {
                                          return(message("input image must be in jpg/jpeg, png or tiff/tif format."))
}

img2 <-img #encrypted values stored here. The image is basically duplicated for debugging purposes.

#get y, x dimensions and channels number
dims <- c(dim(img))

message <- as.character(message)

if (noise == TRUE) {

#add some random noise to all cells
for (x in c(1:dims[2])) {

  for (y in c(1:dims[1])) {

    for (c in c(1:dims[3])) {

      old_val <- img2[y,x,c]

      old_val<- ifelse(old_val==1, 0.99999, old_val) #with the value 1.0000000, substr() returns only 1 without decimals (as it should, I guess). Need to find other solution.

      old_val<- ifelse(old_val==0, 0.000001, old_val)

      val_head <- substr(old_val,1,4) #get initial 4 characters (counting also the decimal separator)

      val_head<- ifelse(nchar(val_head)<4, as.numeric(val_head)+0.01, val_head) #add some decimals in case extracting the value returns an integer

      val_tail <- substr(old_val,5,20) #attempt to preserve part of the original decimal values

      val_tail<- ifelse(nchar(val_tail)<1, 1, val_tail) #convert val_tail to 1 in case there are no digits due to rounding (e.g. if val_head=0.10)

      #update value
      img2[y,x,c] <- as.numeric(paste(c(val_head, sample(1:10, 1), 1, val_tail), collapse="")) #the addition of 1 between sample() and val_tail mirrors the
                                                                                               #compisition of updated values at the end of the script, where
                                                                                               #the added 1 acts as a buffer agains rounding



      }

    }

  }

}


#hash the secret passphrase
scrt_sha <- sha512(as.character(secret), key = as.character(salt))

#change to decimal
#based on: https://stackoverflow.com/questions/27442991/how-to-get-a-hash-code-as-integer-in-r
hex_to_int = function(h) {
  xx = strsplit(tolower(h), "")[[1L]]
  pos = match(xx, c(0L:9L, letters[1L:6L]))
}

int_sha <- paste(hex_to_int(scrt_sha), collapse="")

#get first, middle, and last 3 characters of int_sha. These will be used for the pseudo-random number generation
int_sha.head <- as.numeric(substr(int_sha,1,3))
int_sha.mid <- as.numeric(substr(int_sha,floor((nchar(int_sha)/2))-0,floor((nchar(int_sha)/2))+2))
int_sha.tail <- as.numeric(substr(int_sha,nchar(int_sha)-2,nchar(int_sha)))


#split text into single elements

#txt_splt <- strsplit(message, "")[[1]] #this has some problems with accented letters. Or maybe it's a problem with encoding. I moved to something else without testing.

#if the encoding is "unknown then most likely the message is in ASCII and can be converet to Unicode withouth passing via UTF-8

if (Encoding(message) == "unknown") {

  txt_splt <- as.u_char(utf8ToInt(message))

} else {

  message <- iconv(message, Encoding(message), "UTF-8", "")
  txt_splt <- as.u_char(utf8ToInt(message))

}

#information on message length are stored in a 12-digit format. For this reason the potential maximum number of characters is 999999999999.
if (length(txt_splt) > 999999999999) {return(message("Message exceeeds maximum length. Remove at least ",length(txt_splt) - 999999999999," characters."))}


#Each single element in txt_splt will be conveted into a 12 digits sequence.
#Then each of these 12 digits will have its own pseudo-random set of unique coordinates (x, y and channel)


#generate a coordinate table for each character expected to occur. This is needed to make sure that no identical sets are produced
#use int_sha.head to create a deterministic list of numbers.
#pseudo-random generator is a Linear Congruential Generator based on: e.g. https://www.commonlounge.com/discussion/481152258acb4003a5903d2fc1bc425f


#firs of all produce the cooridnates for the 12-digits length information

len <- 12*3*3 #12 digits and 3 columns (x,y,channel)
              #the final multiplication by 3 is needed so there is a larger pool of combinations to choose from. Pseudo-random generation and rescaling tend
              #to produce duplicates, so it's just better to produce more numbers than needed.

pseud_rand <- numeric(len)

pseud_rand[1] <- as.numeric(paste(int_sha.head, int_sha.mid, int_sha.tail, sep = ""))

for (i in 2:len) {


  a <-  as.numeric(substr(magrittr::mod((int_sha.head*log(i)*pseud_rand[i-1])+int_sha.mid*log(i), int_sha.tail*2^32),1,3))
  b <-  as.numeric(substr(magrittr::mod((int_sha.tail*log(i)*pseud_rand[i-1])+int_sha.head*log(i), int_sha.mid*2^32),1,3))
  c <-  as.numeric(substr(magrittr::mod((int_sha.mid*log(i)*pseud_rand[i-1])+int_sha.tail*log(i), int_sha.head*2^32),1,3))

  pseud_rand[i] <- as.numeric(paste(a,b,c,sep=""))

                                    #this whole mess of pasting is needed because different version of R on different Operating Systems might give different results
                                    #when calculating the modulo. The first 4-5 digits are usually the same from my tests. But I still need a long number to avoid
                                    #producing too many duplicates when rescaling.

  #pseud_rand[i] <- mod(((35*log(i))*pseud_rand[i-1])+528+log(i), 2547-log(i))
}

#select only number in odd or even positions and move them around to break a bit the pattern of simlar numbers.
#code from: https://stackoverflow.com/questions/13461829/select-every-other-element-from-a-vector
pseud_rand.shift <- c(pseud_rand[c(TRUE,FALSE)], rev(pseud_rand[c(FALSE,TRUE)]))

#subtract the rearranged numbers from the pseudo_rand vector. This helps to counter the fact that all numbers have the same lenght, adding some diversity.
pseud_rand.subt <- abs(pseud_rand-rev(pseud_rand.shift))

#fill matrix

#rescale the content of each column:
# - column x contains integers between 1 and dims[2]
# - column y contains integers between 1 and dims[1]
# - column channel contains integers between 1 and dims[3]

length_mx <- as.data.frame(matrix(pseud_rand.subt, nrow = 12*3, ncol = 3, byrow=TRUE))
colnames(length_mx) <- c("x","y","channel")


#rescale x
min_x_new <- 1
max_x_new <- dims[2]

min_x_old <- min(length_mx[,1])
max_x_old <- max(length_mx[,1])

length_mx[,1] <- floor(((max_x_new-min_x_new)/(max_x_old-min_x_old))*(length_mx[,1]-max_x_old)+max_x_new)

#rescale y
min_y_new <- 1
max_y_new <- dims[1]

min_y_old <- min(length_mx[,2])
max_y_old <- max(length_mx[,2])

length_mx[,2] <- floor(((max_y_new-min_y_new)/(max_y_old-min_y_old))*(length_mx[,2]-max_y_old)+max_y_new)

#rescale channel
min_c_new <- 1
max_c_new <-dims[3]

min_c_old <- min(length_mx[,3])
max_c_old <- max(length_mx[,3])

length_mx[,3] <- floor(((max_c_new-min_c_new)/(max_c_old-min_c_old))*(length_mx[,3]-max_c_old)+max_c_new)

#nrow(length_mx)

#change any 0 into 1. The floor function above might generate 0 if the output of the rescaling is a 1
length_mx[length_mx == 0 ] <- 1

#remove duplicate rows (same combination of x, y and channel)
length_mx <- unique(length_mx)
#nrow(length_mx)

#keep only 12 rows
length_mx <- length_mx[13:24,]
#nrow(length_mx)



len <- (((length(txt_splt)*3)*12)*3) #this is the total number of pseudo-random number to generate. length of text * 3 columns * 12 integers and replicated again three times
#the final multiplication by 3 is needed so there is a larger pool of combinations to choose from. Pseudo-random generation and rescaling tend
#to produce duplicates, so it's just better to produce more numbers than needed.
#the +(12*3) is added to store information on text length in a 12-digit format. The value is multiplied by 3 to produce extra coordinates, as above.

start_rand <- pseud_rand[i] #store the last pseudo random value and use it to continue with number generation.

pseud_rand <- numeric(len)

pseud_rand[1] <- start_rand

for (h in 2:len) {

  a <-  as.numeric(substr(magrittr::mod((int_sha.head*log(h)*pseud_rand[h-1])+int_sha.mid*log(h), int_sha.tail*2^32),1,3))
  b <-  as.numeric(substr(magrittr::mod((int_sha.tail*log(h)*pseud_rand[h-1])+int_sha.head*log(h), int_sha.mid*2^32),1,3))
  c <-  as.numeric(substr(magrittr::mod((int_sha.mid*log(h)*pseud_rand[h-1])+int_sha.tail*log(h), int_sha.head*2^32),1,3))

  pseud_rand[h] <- as.numeric(paste(a,b,c,sep=""))

  #pseud_rand[h] <- mod(((35*log(h))*pseud_rand[h-1])+528+log(h), 2547-log(h))
}

#select only number in odd or even positions and move them around to break a bit the pattern of simlar numbers.
#code from: https://stackoverflow.com/questions/13461829/select-every-other-element-from-a-vector
pseud_rand.shift <- c(pseud_rand[c(TRUE,FALSE)], rev(pseud_rand[c(FALSE,TRUE)]))

#subtract the rearranged numbers from the pseudo_rand vector. This helps to counter the fact that all numbers have the same lenght, adding some diversity.
pseud_rand.subt <- abs(pseud_rand-rev(pseud_rand.shift))


#fill matrix
mx <- as.data.frame(matrix(pseud_rand.subt, nrow = length(txt_splt)*3*12, ncol = 3, byrow=TRUE))
colnames(mx) <- c("x","y","channel")



#rescale x
min_x_new <- 1
max_x_new <- dims[2]

min_x_old <- min(mx[,1])
max_x_old <- max(mx[,1])

mx[,1] <- floor(((max_x_new-min_x_new)/(max_x_old-min_x_old))*(mx[,1]-max_x_old)+max_x_new)

#rescale y
min_y_new <- 1
max_y_new <- dims[1]

min_y_old <- min(mx[,2])
max_y_old <- max(mx[,2])

mx[,2] <- floor(((max_y_new-min_y_new)/(max_y_old-min_y_old))*(mx[,2]-max_y_old)+max_y_new)

#rescale channel
min_c_new <- 1
max_c_new <-dims[3]

min_c_old <- min(mx[,3])
max_c_old <- max(mx[,3])

mx[,3] <- floor(((max_c_new-min_c_new)/(max_c_old-min_c_old))*(mx[,3]-max_c_old)+max_c_new)

nrow(mx)

#remove duplicate rows (same combination of x, y and channel)
mx <- unique(mx)
nrow(mx)


#add the two data frames
all_mx <- rbind(length_mx, mx)

#change any 0 into 1. The floor function above might generate 0 if the output of the rescaling is a 1
all_mx[all_mx == 0 ] <- 1

#remove unique
all_mx <- unique(all_mx)
nrow(all_mx)

#remove all the rows contained in length_mx
mx <- dplyr::setdiff(all_mx, length_mx)
nrow(mx)


#add what remains to length_mx. In this way it is certain that what remains of mx does not contain duplicates of length_mx
mx <- rbind(length_mx, mx)
nrow(mx)


if (nrow(mx) < (((length(txt_splt))*12)+12)) {return(message("Message length exceed pseudo-random generator capacity. Shorten message or choose larger image. Length required: ",(((length(txt_splt))*12)+12)," Length available: ", nrow(mx)))}

#keep only the first length(txt_splt) rows.
mx <- mx[1:(((length(txt_splt))*12)+12),]
#nrow(mx)


map <- setNames(c("22", "23","24","25","32","33","34","35","42","43","44","45","52","53","54","55","65","75"),
                c("0", "1", "2","3","4","5","6","7","8","9","A","B","C","D","E","F","0","0"))

#Create function to convert Unicode strings into 12-digits integers
Uni2int <-  function(x) {

  #old coversion scheme
  #x <- strsplit(tolower(x), "")[[1L]]
  #x <- match(x, c(0L:9L, letters[1L:6L]))
  #x <- x+10 #add 10 so every individual number has 2 digits
  #x <- paste(x,collapse="")



  x <- strsplit(x, "")[[1L]]
  x[] <- map[unlist(x)] #code for unlist substitution taken from: https://stackoverflow.com/questions/7547597/dictionary-style-replace-multiple-items
  x <- paste(x,collapse="")


  if (nchar(x) == 8)  #unicode has a maximum of 6 characters. This means that it could produce a 12-digits integers
                      #But many Unicode codes are shorted than that (generally 4 characters). Nonetheless, all of them
                      #must be converted to a uniform 12 digits format for consistency
  {

    x <- as.numeric(x) + 657500000000

  } else if (nchar(x) == 10) {

    x <- as.numeric(x) + 650000000000

  } else if (nchar(mx$text) == 12) {

    x <- as.numeric(x)

  } else {

    print("Error in conversion to integer")

  }

} #end function


#store data on text length in the first 12 pixels

#produce a 12-digits vector to store text length. In this way the decoding script can process the first 12 digits, get text length and know when to stop decoding.

message_length <- c(integer(12-nchar(length(txt_splt))),as.numeric(strsplit(as.character(length(txt_splt)), "")[[1]])) #since thex length is stored in a 12-digits format, this
                                                                                                                       #defines also the limit for maximum potential text length
counter <- 1

for (z in c(1:length(message_length))) {

  length_digit <- message_length[z]

  xval <- mx[counter,1]
  yval <- mx[counter,2]
  chan <- mx[counter,3]

  #print(paste("Storing length digit ", length_digit, " - Counter ", counter, " - x ", xval, ", y ", yval, ", c ",chan <- mx[counter,3]))



  #replace old value with new one

  old_val <- img2[yval,xval,chan]

  old_val<- old_val+0.011

  old_val<- ifelse(old_val>=1, 0.999, old_val) #with the value 1.0000000, substr() returns only 1 without decimals (as it should, I guess). Need to find other solution.

  #old_val<- ifelse(old_val==0, 0.000001, old_val)

  val_head <- substr(old_val,1,4) #get initial 4 characters (counting also the decimal separator)

  #get last 2 characters
  #for the moment the tail part is left out. It nchar() does not work with values like 0.80000000000000004, where it returns simply 3
  #old_tail <- substr(old_val,nchar(old_val)-2,nchar(old_val))
  val_tail <- "0"  #all tails are replaced with 0. This should provide some level of control in case some rounding occurs

  #update value
  img2[yval,xval,chan] <- as.numeric(paste(c(val_head, length_digit, val_tail), collapse=""))

  counter <- counter +1

}


while (counter < (length(txt_splt)*12)+12+1 ) { #repeat until all elements within each 12-digit integer have been processed

#while (counter < 12 ) {

for (q in c(1:length(txt_splt))) {


  #remove the "U+" part
  step_1 <- sub("U\\+", "", txt_splt[q])

  #convert the Unicode code into a 12-digit sequence
  step_2 <- Uni2int(step_1)

  #print(paste("Processing ",txt_splt[q], " - val ", step_2, sep=""))


  for (w in c(1:12)) {

  step_3 <-  as.numeric(substr(step_2,w,w))



  xval <- mx[counter,1]
  yval <- mx[counter,2]
  chan <- mx[counter,3]

  #replace old value with new one

  old_val <- img2[yval,xval,chan]

  old_val<- old_val+0.011

  old_val<- ifelse(old_val>=1, 0.999, old_val) #with the value 1.0000000, substr() returns only 1 without decimals (as it should, I guess). Need to find other solution.

  #old_val<- ifelse(old_val==0, 0.000001, old_val)

  val_head <- substr(old_val,1,4) #get initial 4 characters (counting also the decimal separator)

  val_head<- ifelse(nchar(val_head)<4, as.numeric(val_head)+0.01, val_head) #this is needed in case some decimal digits get truncated, e.g. 0.80 becoming 0.8
                                                                            #In this case the coded value would be appended to the wrong position

  val_tail <- substr(old_val,5,20) #attempt to preserve part of the original decimal values
  val_tail<- ifelse(nchar(val_tail)<1, 1, val_tail) #convert val_tail to 1 in case there are no digits due to rounding (e.g. if val_head=0.10)

  #update value
  img2[yval,xval,chan] <- as.numeric(paste(c(val_head, step_3, 1, val_tail), collapse="")) #the addition of 1 between step_3 and val_tail acts as a buffer against rounding

  #debugging
  #if (counter > (length(txt_splt)*12) ) {
  #  print(paste("Processing digit ", step_3, " - Counter ", counter, " - x ", mx[counter,1], ", y ", mx[counter,2], ", c ",mx[counter,3], "Old val: ", old_val, " New val: ", as.numeric(paste(c(val_head, step_3, val_tail), collapse=""))))
  #}



  counter <- counter +1

  }

}

} #end while



outfile <- paste(output,".tiff", sep="")
#message("outfile: ", outfile)


writeTIFF(what = img2, where = outfile, bits.per.sample = 16L, compression="none", reduce=FALSE)
message("message stored in ", outfile)


}

